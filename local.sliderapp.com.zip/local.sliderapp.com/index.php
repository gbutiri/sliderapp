<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Slider Calculator</title>
	
	<link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/bootstrap/css/bootstrap-theme.min.css" />
	<link rel="stylesheet" href="/jquery-ui/jquery-ui.min.css" />
	<link rel="stylesheet" href="/jquery-ui/jquery-ui.structure.min.css" />
	<link rel="stylesheet" href="/jquery-ui/jquery-ui.theme.min.css" />
	<link rel="stylesheet" href="/css/main.css" />

	<script src="/js/jquery-2.2.1.min.js"></script>
	<script src="/jquery-ui/jquery-ui.min.js"></script>
	<script src="/bootstrap/js/bootstrap.min.js"></script>
	
	<script src="/js/main.js"></script>

</head>

<body>
	<div class="container">
		<p>Total Debt: $ <input type="text" id="debt" value="0" /> Billion</p>
		<p>Taxes Collected: $ <input type="text" id="income" value="0" /> Billion</p>
		<p>Money Spent: $ <input type="text" id="expenses" value="0" /> Billion</p>
		<p>Interest (6%): $ <input type="text" id="interest" value="0" /> Billion</p>
		<p>Surplus: $ <input type="text" id="surplus" value="0" /> Billion</p>
		<div>&nbsp;</div>
		
		<?php 
		$budgets = array(
			'social' => 1276,
			'medicare' => 1051,
			'military' => 609,
			// 'interest_6_percent' => 229,
			'veterans' => 160,
			'food' => 136,
			'education' => 102,
			'transportation' => 85,
			'housing' => 61,
			'international' => 50,
			'energy_environment' => 45,
			'science' => 30,
		);
		
		foreach ($budgets as $key => $budget) {
			?>
			<div class="col-sm-6 col-md-4 col-lg-3 slider-container">
				<label for="<?php echo $key; ?>">
					<?php echo $key; ?>: 
					$<input class="the_value" type="text" id="<?php echo $key; ?>" readonly>
				</label>
				<div class="slider" data-affect="<?php echo $key; ?>" data-val="<?php echo $budget; ?>"></div>
				<div id="<?php echo $key; ?>_indicator" class="indicator"></div>
				
			</div>
			<?php
		}
		?>

		
	</div>
</body>

</html>