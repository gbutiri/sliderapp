$(function() {


	Number.prototype.numberFormat = function(c, d, t){
		var n = this, 
			c = isNaN(c = Math.abs(c)) ? 2 : c, 
			d = d == undefined ? "." : d, 
			t = t == undefined ? "," : t, 
			s = n < 0 ? "-" : "", 
			i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
			j = (j = i.length) > 3 ? j % 3 : 0;
		return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
	};
	
	var renderTotals = function () {
		var _indicator_max = 0;
		var _expenses = 0;
		var _surplus = 0;
		$('.slider').each(function() {
			var $this = $(this);
			
			var _this_expense = parseInt($this.slider('option','value'));
			if (_this_expense > _indicator_max) {_indicator_max = _this_expense;}
			_expenses += _this_expense;
		});
		
		// for rendering the bars.
		console.log(_indicator_max);
		$('.slider').each(function() {
			var $this = $(this);
			var _val = $this.slider('option', 'value');
			$('#' + $this.attr('data-affect') + '_indicator').width((parseFloat(_val / _indicator_max) * 100) + '%');
			
		});
		
		$('#expenses').val(_expenses.numberFormat(2));
		var _interest = _expenses * 0.06;
		$('#interest').val(_interest.numberFormat(2));
		_surplus = _total_income - _expenses - _interest;
		$('#surplus').val(_surplus.numberFormat(2));
	}
	
	// TOTAL INCOME
	var _total_debt = 59400;
	var _total_income = 3248.723;
	$('#debt').val(_total_debt.numberFormat(2));
	$('#income').val(_total_income.numberFormat(2));
	
	var _step = 100;
	
	
	$( ".slider" ).each(function() {
		
		var $this = $(this);
		var _val = parseInt($this.attr('data-val'));
		var _min = _val - _step;
		if (_min <= 0) {_min = 0;}
		var _max = _val + _step;
		var _id = $this.id;
		var _affect = $this.attr('data-affect');
		$this.slider({
			range: "max",
			min: _min,
			max: _max,
			value: _val,
			slide: function( event, ui ) {
				$( "#" + _affect ).val( ui.value.numberFormat(2) + ' B' );
				renderTotals();
			},
			stop: function ( event, ui ) {
				var _newmin = ui.value - _step;
				if (_newmin <= 0) {_newmin = 0;}
				$this.slider({min: (_newmin) });
				$this.slider({max: (ui.value + _step) });
				renderTotals();
			}
		});
		$( "#" + _affect ).val( $this.slider( "value" ).numberFormat(2) + ' B' );
	});
	renderTotals();
  });